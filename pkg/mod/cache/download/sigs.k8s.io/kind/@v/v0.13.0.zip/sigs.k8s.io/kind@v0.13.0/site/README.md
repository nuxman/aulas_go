# kind's docs

kind's docs are built with [hugo], and can be browsed live at https://kind.sigs.k8s.io/

To browse them locally, install hugo and run `make serve` from this directory.

[hugo]: https://gohugo.io
