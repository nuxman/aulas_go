# gimme

This is an unmodified copy of [gimme], so we don't have to download it
from the internet.

[gimme]: https://github.com/travis-ci/gimme