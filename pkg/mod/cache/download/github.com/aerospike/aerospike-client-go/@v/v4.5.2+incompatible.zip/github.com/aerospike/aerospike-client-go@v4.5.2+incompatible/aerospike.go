// Package aerospike provides a client to connect and interact with an Aerospike cluster.
// This is the official Go implementation of the Aerospike Client.
package aerospike
